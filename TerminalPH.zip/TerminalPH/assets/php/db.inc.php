<?php
$servername = "localhost";
$username = "root1";
$password = "";
$dbname = "db_terminal";
?>